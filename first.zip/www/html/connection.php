<?php
$host = '192.168.0.10';
$user = 'root';
$password = 'root';
$db = 'test_db';
?>
